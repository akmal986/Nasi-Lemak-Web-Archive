let searchInputs = document.querySelectorAll(".s");
for (let i = 0; i < searchInputs.length; i++) {
  searchInputs[i].placeholder = php_vars.search_placeholder;
} 